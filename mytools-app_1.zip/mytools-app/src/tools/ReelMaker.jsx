import { useState, useEffect, useRef } from "react";

const PLATFORM_TABS = [
  { id: "ig-reels", label: "Instagram Reels", icon: "▶", color: "#E1306C", platform: "instagram" },
  { id: "ig-stories", label: "Instagram Stories", icon: "◉", color: "#F77737", platform: "instagram" },
  { id: "yt-shorts", label: "YouTube Shorts", icon: "⚡", color: "#FF0000", platform: "youtube" },
  { id: "yt-long", label: "YouTube Видео", icon: "▭", color: "#CC0000", platform: "youtube" },
  { id: "ig-zero", label: "Instagram с нуля", icon: "✦", color: "#833AB4", platform: "instagram" },
  { id: "yt-zero", label: "YouTube с нуля", icon: "★", color: "#FF4500", platform: "youtube" },
];

const QUICK_TOPICS = {
  instagram: ["ibratli video", "motivatsiya", "hayot darslari", "biznes maslahat", "oila", "sport", "pul ishlash", "psixologiya"],
  youtube: ["vlog", "obzor", "ta'lim", "intervyu", "challenge", "travel", "cooking", "texnologiya"],
};

function TypingText({ text }) {
  const [displayed, setDisplayed] = useState("");
  const [done, setDone] = useState(false);
  const idx = useRef(0);

  useEffect(() => {
    setDisplayed("");
    setDone(false);
    idx.current = 0;
    if (!text) return;
    const interval = setInterval(() => {
      if (idx.current < text.length) {
        setDisplayed(text.slice(0, idx.current + 1));
        idx.current++;
      } else {
        setDone(true);
        clearInterval(interval);
      }
    }, 8);
    return () => clearInterval(interval);
  }, [text]);

  return <span>{displayed}{!done && <span className="cursor">|</span>}</span>;
}

export default function ReelMaker({ onBack }) {
  const [activeTab, setActiveTab] = useState("ig-reels");
  const [topic, setTopic] = useState("");
  const [script, setScript] = useState("");
  const [loading, setLoading] = useState(false);
  const [trendLoading, setTrendLoading] = useState(null);
  const [trendTopics, setTrendTopics] = useState([]);
  const [error, setError] = useState("");
  const [phase, setPhase] = useState("idle"); // idle | trends | scripting | done

  const currentTab = PLATFORM_TABS.find(t => t.id === activeTab);
  const quickTopics = QUICK_TOPICS[currentTab.platform];

  const fetchTrends = async (platform) => {
    setTrendLoading(platform);
    setTrendTopics([]);
    setScript("");
    setPhase("trends");
    setError("");
    try {
      const platformName = platform === "instagram" ? "Instagram (Uzbek audience)" : "YouTube Uzbekistan";
      const res = await fetch("/api/ai", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          tools: [{ type: "web_search_20250305", name: "web_search" }],
          system: `Siz ${platformName} platformasida hozirgi eng trendli mavzularni tahlil qiladigan ekspertsiz. 
Faqat JSON formatida javob bering, hech qanday markdown yoki izoh qo'shmang.
Format: {"trends": ["mavzu1", "mavzu2", "mavzu3", "mavzu4", "mavzu5", "mavzu6"]}
Mavzular o'zbek tilida bo'lishi kerak, qisqa va aniq.`,
          messages: [{
            role: "user",
            content: `Hozir ${platformName} da eng ko'p ko'rilayotgan, viral bo'layotgan 6 ta mavzuni toping. O'zbek auditoriyasi uchun. Faqat JSON qaytaring.`
          }]
        })
      });
      const data = await res.json();
      const fullText = data.content.filter(b => b.type === "text").map(b => b.text).join("");
      const clean = fullText.replace(/```json|```/g, "").trim();
      const parsed = JSON.parse(clean);
      setTrendTopics(parsed.trends || []);
    } catch (e) {
      setError("Trendlarni yuklashda xatolik. Qayta urinib ko'ring.");
    } finally {
      setTrendLoading(null);
      setPhase("idle");
    }
  };

  const generateScript = async (customTopic) => {
    const finalTopic = customTopic || topic;
    if (!finalTopic.trim()) { setError("Mavzu kiriting!"); return; }
    setLoading(true);
    setScript("");
    setError("");
    setPhase("scripting");

    const tabInfo = PLATFORM_TABS.find(t => t.id === activeTab);
    const formatMap = {
      "ig-reels": "Instagram Reels (15-60 sekund, qisqa, emotsional, hook bilan boshlanadi)",
      "ig-stories": "Instagram Stories (15 sekund, 3-5 ta slayd, interaktiv, CTA bilan)",
      "yt-shorts": "YouTube Shorts (60 sekund, tez ritmli, hook birinchi 3 sekundda)",
      "yt-long": "YouTube uzun video (8-15 daqiqa, batafsil, kirish + asosiy qism + xulosa)",
      "ig-zero": "Instagram dan noldan boshlash (profil strategiyasi + birinchi 10 ta post + Reels rejasi)",
      "yt-zero": "YouTube dan noldan boshlash (kanal strategiyasi + birinchi 10 ta video + o'sish taktikasi)",
    };

    try {
      const res = await fetch("/api/ai", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          system: `Siz professional content creator va ssenariy yozuvchisiz. O'zbek auditoriyasi uchun viral kontentlar yaratasiz.
Format: ${formatMap[activeTab]}
Ssenariy o'zbek tilida bo'lsin. Real, ijodiy, va viral bo'ladigan ssenariy yozing.
Strukturasi aniq ko'rinsin: HOOK, ASOSIY QISM, TUGASH/CTA.`,
          messages: [{
            role: "user",
            content: `"${finalTopic}" mavzusida ${formatMap[activeTab]} uchun professional ssenariy yozing. Real odamlar uchun, haqiqiy va viral bo'ladigan tarzda.`
          }]
        })
      });
      const data = await res.json();
      const text = data.content.filter(b => b.type === "text").map(b => b.text).join("");
      setScript(text);
      setPhase("done");
    } catch (e) {
      setError("Ssenariy yaratishda xatolik. Qayta urinib ko'ring.");
      setPhase("idle");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      minHeight: "100vh",
      background: "#0A0A0F",
      color: "#fff",
      fontFamily: "'Space Mono', 'Courier New', monospace",
      padding: "0",
      overflowX: "hidden",
    }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Bebas+Neue&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        .cursor { animation: blink 0.7s infinite; }
        @keyframes blink { 0%,100%{opacity:1} 50%{opacity:0} }
        .tab-btn { transition: all 0.2s; border: none; cursor: pointer; }
        .tab-btn:hover { transform: translateY(-2px); }
        .trend-chip { transition: all 0.2s; cursor: pointer; }
        .trend-chip:hover { transform: scale(1.04); }
        .gen-btn { transition: all 0.18s; cursor: pointer; border: none; }
        .gen-btn:hover:not(:disabled) { transform: scale(1.03); filter: brightness(1.12); }
        .gen-btn:disabled { opacity: 0.5; cursor: not-allowed; }
        .script-box { animation: fadeIn 0.5s ease; }
        @keyframes fadeIn { from{opacity:0;transform:translateY(10px)} to{opacity:1;transform:translateY(0)} }
        .pulse { animation: pulse 1.5s infinite; }
        @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.4} }
        textarea { resize: none; }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-track { background: #111; }
        ::-webkit-scrollbar-thumb { background: #333; border-radius: 4px; }
      `}</style>

      {/* HEADER */}
      <div style={{
        background: "linear-gradient(135deg, #0A0A0F 0%, #12121A 100%)",
        borderBottom: "1px solid #1E1E2E",
        padding: "28px 24px 20px",
        position: "relative",
        overflow: "hidden",
      }}>
        <div style={{
          position: "absolute", top: "-60px", right: "-60px",
          width: "200px", height: "200px",
          background: `radial-gradient(circle, ${currentTab.color}33 0%, transparent 70%)`,
          borderRadius: "50%", transition: "all 0.5s",
        }} />
        <div style={{ position: "relative", zIndex: 1 }}>
          {onBack && <button onClick={onBack} style={{ background: "rgba(255,255,255,0.08)", border: "1px solid #333", borderRadius: 8, padding: "6px 14px", color: "#888", cursor: "pointer", fontSize: 12, fontFamily: "inherit", letterSpacing: "1px", marginBottom: 12 }}>← ORQAGA</button>}
          <div style={{
            display: "flex", alignItems: "center", gap: "12px", marginBottom: "6px"
          }}>
            <div style={{
              width: "36px", height: "36px", borderRadius: "10px",
              background: `linear-gradient(135deg, ${currentTab.color}, ${currentTab.color}88)`,
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: "18px", fontWeight: "bold",
            }}>⚡</div>
            <div>
              <div style={{
                fontFamily: "'Bebas Neue', sans-serif",
                fontSize: "28px", letterSpacing: "3px",
                background: `linear-gradient(90deg, #fff, ${currentTab.color})`,
                WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
              }}>VIRAL MAKER</div>
            </div>
          </div>
          <div style={{ fontSize: "11px", color: "#555", letterSpacing: "2px" }}>
            O'ZBEKISTON · AI CONTENT GENERATOR · REAL-TIME TRENDS
          </div>
        </div>
      </div>

      <div style={{ padding: "20px 16px", maxWidth: "680px", margin: "0 auto" }}>

        {/* PLATFORM TABS */}
        <div style={{ marginBottom: "20px" }}>
          <div style={{ fontSize: "10px", color: "#444", letterSpacing: "2px", marginBottom: "10px" }}>
            PLATFORM TANLANG
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "8px" }}>
            {PLATFORM_TABS.map(tab => (
              <button
                key={tab.id}
                className="tab-btn"
                onClick={() => { setActiveTab(tab.id); setScript(""); setTrendTopics([]); setError(""); }}
                style={{
                  padding: "10px 8px",
                  borderRadius: "10px",
                  background: activeTab === tab.id
                    ? `linear-gradient(135deg, ${tab.color}22, ${tab.color}11)`
                    : "#111118",
                  border: activeTab === tab.id
                    ? `1.5px solid ${tab.color}66`
                    : "1.5px solid #1E1E2E",
                  color: activeTab === tab.id ? tab.color : "#444",
                  fontSize: "10px",
                  fontFamily: "inherit",
                  letterSpacing: "0.5px",
                  textAlign: "center",
                  lineHeight: "1.4",
                }}
              >
                <div style={{ fontSize: "16px", marginBottom: "4px" }}>{tab.icon}</div>
                <div>{tab.label}</div>
              </button>
            ))}
          </div>
        </div>

        {/* TREND BUTTONS */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px", marginBottom: "20px" }}>
          {["instagram", "youtube"].map(p => (
            <button
              key={p}
              className="gen-btn"
              onClick={() => fetchTrends(p)}
              disabled={!!trendLoading}
              style={{
                padding: "14px 12px",
                borderRadius: "12px",
                background: trendLoading === p
                  ? "#1A1A25"
                  : p === "instagram"
                    ? "linear-gradient(135deg, #E1306C22, #F7773722)"
                    : "linear-gradient(135deg, #FF000022, #CC000022)",
                border: p === "instagram"
                  ? "1.5px solid #E1306C44"
                  : "1.5px solid #FF000044",
                color: p === "instagram" ? "#E1306C" : "#FF4444",
                fontSize: "11px",
                fontFamily: "inherit",
                letterSpacing: "1px",
                display: "flex", alignItems: "center", gap: "8px",
              }}
            >
              {trendLoading === p
                ? <span className="pulse">⟳ YUKLANYAPTI...</span>
                : <>
                    <span style={{ fontSize: "16px" }}>{p === "instagram" ? "📱" : "▶"}</span>
                    <span>TRENDLAR<br />{p === "instagram" ? "INSTAGRAM" : "YOUTUBE"}</span>
                  </>
              }
            </button>
          ))}
        </div>

        {/* TREND CHIPS */}
        {trendTopics.length > 0 && (
          <div style={{ marginBottom: "20px" }}>
            <div style={{ fontSize: "10px", color: "#555", letterSpacing: "2px", marginBottom: "10px" }}>
              🔥 HOZIR TREND — BOSING VA SSENARIY OLING
            </div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: "8px" }}>
              {trendTopics.map((t, i) => (
                <button
                  key={i}
                  className="trend-chip gen-btn"
                  onClick={() => { setTopic(t); generateScript(t); }}
                  style={{
                    padding: "8px 14px",
                    borderRadius: "20px",
                    background: "#111118",
                    border: `1.5px solid ${currentTab.color}44`,
                    color: currentTab.color,
                    fontSize: "11px",
                    fontFamily: "inherit",
                    letterSpacing: "0.5px",
                  }}
                >
                  ✦ {t}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* QUICK TOPICS */}
        <div style={{ marginBottom: "16px" }}>
          <div style={{ fontSize: "10px", color: "#444", letterSpacing: "2px", marginBottom: "10px" }}>
            TEZKOR MAVZULAR
          </div>
          <div style={{ display: "flex", flexWrap: "wrap", gap: "6px" }}>
            {quickTopics.map((t, i) => (
              <button
                key={i}
                className="trend-chip gen-btn"
                onClick={() => setTopic(t)}
                style={{
                  padding: "6px 12px",
                  borderRadius: "16px",
                  background: topic === t ? `${currentTab.color}22` : "#0D0D15",
                  border: `1px solid ${topic === t ? currentTab.color + "66" : "#1E1E2E"}`,
                  color: topic === t ? currentTab.color : "#555",
                  fontSize: "10px",
                  fontFamily: "inherit",
                }}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        {/* TOPIC INPUT */}
        <div style={{ marginBottom: "16px" }}>
          <div style={{ fontSize: "10px", color: "#444", letterSpacing: "2px", marginBottom: "8px" }}>
            O'Z MAVZUINGIZNI YOZING
          </div>
          <div style={{ position: "relative" }}>
            <textarea
              value={topic}
              onChange={e => setTopic(e.target.value)}
              placeholder="Masalan: pul ishlash usullari, motivatsiya, ibratli hikoya..."
              rows={2}
              style={{
                width: "100%",
                background: "#0D0D15",
                border: `1.5px solid ${currentTab.color}33`,
                borderRadius: "12px",
                color: "#fff",
                padding: "12px 14px",
                fontSize: "13px",
                fontFamily: "inherit",
                outline: "none",
                letterSpacing: "0.3px",
              }}
              onFocus={e => e.target.style.borderColor = currentTab.color + "88"}
              onBlur={e => e.target.style.borderColor = currentTab.color + "33"}
              onKeyDown={e => e.key === "Enter" && !e.shiftKey && (e.preventDefault(), generateScript())}
            />
          </div>
        </div>

        {/* ERROR */}
        {error && (
          <div style={{
            padding: "10px 14px", borderRadius: "10px",
            background: "#FF000011", border: "1px solid #FF000033",
            color: "#FF6666", fontSize: "12px", marginBottom: "14px"
          }}>
            ⚠ {error}
          </div>
        )}

        {/* GENERATE BUTTON */}
        <button
          className="gen-btn"
          onClick={() => generateScript()}
          disabled={loading}
          style={{
            width: "100%",
            padding: "16px",
            borderRadius: "12px",
            background: loading
              ? "#111"
              : `linear-gradient(135deg, ${currentTab.color}, ${currentTab.color}BB)`,
            color: "#fff",
            fontSize: "13px",
            fontFamily: "'Bebas Neue', sans-serif",
            letterSpacing: "3px",
            marginBottom: "24px",
            boxShadow: loading ? "none" : `0 4px 24px ${currentTab.color}44`,
          }}
        >
          {loading
            ? <span className="pulse">⟳ SSENARIY YARATILMOQDA...</span>
            : `⚡ SSENARIY YARATISH — ${currentTab.label.toUpperCase()}`}
        </button>

        {/* SCRIPT OUTPUT */}
        {script && (
          <div className="script-box" style={{
            background: "#0D0D15",
            border: `1.5px solid ${currentTab.color}44`,
            borderRadius: "16px",
            padding: "20px",
            marginBottom: "20px",
            position: "relative",
            boxShadow: `0 0 40px ${currentTab.color}11`,
          }}>
            <div style={{
              display: "flex", justifyContent: "space-between", alignItems: "center",
              marginBottom: "16px", paddingBottom: "12px",
              borderBottom: "1px solid #1E1E2E",
            }}>
              <div style={{ fontSize: "10px", color: currentTab.color, letterSpacing: "2px" }}>
                ✦ {currentTab.label.toUpperCase()} SSENARIYI
              </div>
              <button
                onClick={() => navigator.clipboard?.writeText(script)}
                style={{
                  background: "#1A1A25", border: "1px solid #2A2A3A",
                  color: "#888", padding: "4px 10px", borderRadius: "6px",
                  fontSize: "10px", cursor: "pointer", fontFamily: "inherit",
                  letterSpacing: "1px",
                }}
              >
                COPY
              </button>
            </div>
            <div style={{
              fontSize: "13px", lineHeight: "1.8", color: "#CCC",
              whiteSpace: "pre-wrap", letterSpacing: "0.3px",
            }}>
              <TypingText text={script} />
            </div>
          </div>
        )}

        {/* FOOTER */}
        <div style={{ textAlign: "center", fontSize: "10px", color: "#2A2A3A", letterSpacing: "2px", paddingBottom: "30px" }}>
          POWERED BY CLAUDE AI · VIRAL MAKER UZ
        </div>
      </div>
    </div>
  );
}
