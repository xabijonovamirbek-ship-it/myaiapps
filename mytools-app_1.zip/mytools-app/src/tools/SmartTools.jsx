import { useState, useRef } from "react";

const LANGUAGES = [
  { code: "ru", label: "Русский" },
  { code: "uz", label: "O'zbek" },
  { code: "en", label: "English" },
];

const TABS = [
  { id: "resume", icon: "📄", label: "Резюме" },
  { id: "translate", icon: "🌐", label: "Перевод" },
  { id: "poem", icon: "✍️", label: "Стихи" },
  { id: "names", icon: "👶", label: "Имена" },
];

const S = {
  // Inputs
  input: {
    width: "100%",
    background: "rgba(255,255,255,0.08)",
    border: "1px solid rgba(255,255,255,0.15)",
    borderRadius: 14,
    padding: "12px 16px",
    color: "#fff",
    fontSize: 14,
    outline: "none",
    boxSizing: "border-box",
    fontFamily: "inherit",
  },
  textarea: {
    width: "100%",
    background: "rgba(255,255,255,0.08)",
    border: "1px solid rgba(255,255,255,0.15)",
    borderRadius: 14,
    padding: "12px 16px",
    color: "#fff",
    fontSize: 14,
    outline: "none",
    boxSizing: "border-box",
    fontFamily: "inherit",
    resize: "none",
  },
  // Buttons
  btnPrimary: {
    width: "100%",
    padding: "14px 0",
    borderRadius: 18,
    background: "linear-gradient(135deg, #7C3AED, #9333EA)",
    color: "#fff",
    fontWeight: 700,
    fontSize: 14,
    border: "none",
    cursor: "pointer",
    transition: "opacity 0.2s",
  },
  btnPrimaryDisabled: {
    width: "100%",
    padding: "14px 0",
    borderRadius: 18,
    background: "linear-gradient(135deg, #7C3AED, #9333EA)",
    color: "#fff",
    fontWeight: 700,
    fontSize: 14,
    border: "none",
    cursor: "not-allowed",
    opacity: 0.4,
  },
  btnLang: (active) => ({
    flex: 1,
    padding: "10px 0",
    borderRadius: 14,
    background: active ? "#7C3AED" : "rgba(255,255,255,0.08)",
    color: active ? "#fff" : "rgba(255,255,255,0.5)",
    fontWeight: 600,
    fontSize: 13,
    border: "none",
    cursor: "pointer",
  }),
  // Cards
  card: {
    background: "rgba(255,255,255,0.07)",
    borderRadius: 18,
    padding: 20,
    border: "1px solid rgba(255,255,255,0.12)",
  },
};

async function callClaude(prompt, systemPrompt = "") {
  const response = await fetch("/api/ai", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-6",
      max_tokens: 1000,
      system: systemPrompt || "You are a helpful assistant.",
      messages: [{ role: "user", content: prompt }],
    }),
  });
  const data = await response.json();
  return data.content?.map((b) => b.text || "").join("") || "";
}

// ─── RESUME ─────────────────────────────────────────────────────────────────
function ResumeTool() {
  const [form, setForm] = useState({
    firstName: "", lastName: "", phone: "", email: "",
    city: "", jobTitle: "", company: "", experience: "",
    education: "", skills: "", lang: "ru",
  });
  const [photo, setPhoto] = useState(null);
  const [photoPreview, setPhotoPreview] = useState(null);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const fileRef = useRef();

  const handlePhoto = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setPhoto(file);
    setPhotoPreview(URL.createObjectURL(file));
  };

  const langLabels = { ru: "русском", uz: "o'zbek tilida", en: "English" };

  const generate = async () => {
    setLoading(true);
    setResult(null);
    try {
      const prompt = `Создай профессиональное резюме на ${langLabels[form.lang]} языке для следующего человека.
Верни ТОЛЬКО JSON без markdown блоков в формате:
{
  "name": "Имя Фамилия",
  "jobTitle": "Должность",
  "contact": "Телефон | Email | Город",
  "summary": "Краткое описание 2-3 предложения",
  "experience": [{"role":"","company":"","desc":""}],
  "education": "Образование",
  "skills": ["навык1","навык2"]
}

Данные:
Имя: ${form.firstName} ${form.lastName}
Телефон: ${form.phone}
Email: ${form.email}
Город: ${form.city}
Должность: ${form.jobTitle}
Компания/опыт: ${form.company}
Опыт работы: ${form.experience}
Образование: ${form.education}
Навыки: ${form.skills}`;

      const raw = await callClaude(prompt, "You are a professional resume writer. Return only valid JSON, no markdown.");
      const clean = raw.replace(/```json|```/g, "").trim();
      const parsed = JSON.parse(clean);
      setResult(parsed);
    } catch (e) {
      setResult({ error: "Ошибка генерации. Попробуй снова." });
    }
    setLoading(false);
  };

  const printResume = () => {
    const win = window.open("", "_blank");
    const photoHTML = photoPreview
      ? `<img src="${photoPreview}" style="width:110px;height:110px;border-radius:50%;object-fit:cover;border:3px solid #7C3AED;display:block;margin-bottom:12px;" />`
      : `<div style="width:110px;height:110px;border-radius:50%;background:#e0ddff;display:flex;align-items:center;justify-content:center;font-size:38px;margin-bottom:12px;">👤</div>`;

    win.document.write(`<!DOCTYPE html><html><head><meta charset="UTF-8">
<title>Resume</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap');
  *{margin:0;padding:0;box-sizing:border-box;}
  body{font-family:'Inter',sans-serif;background:#fff;color:#1a1a2e;}
  .page{display:flex;min-height:100vh;}
  .sidebar{width:220px;background:#7C3AED;color:#fff;padding:32px 20px;flex-shrink:0;}
  .sidebar h1{font-size:20px;font-weight:700;margin-bottom:4px;}
  .sidebar .title{font-size:12px;opacity:.8;margin-bottom:20px;}
  .sidebar .sec{font-size:10px;text-transform:uppercase;letter-spacing:1.5px;opacity:.7;margin:18px 0 8px;}
  .sidebar p{font-size:12px;line-height:1.6;opacity:.9;}
  .skill-tag{display:inline-block;background:rgba(255,255,255,.2);border-radius:12px;padding:3px 10px;font-size:11px;margin:3px 2px;}
  .main{flex:1;padding:40px 36px;}
  .sec-head{font-size:13px;font-weight:700;color:#7C3AED;text-transform:uppercase;letter-spacing:1px;border-bottom:2px solid #7C3AED;padding-bottom:4px;margin:24px 0 12px;}
  .summary{font-size:13px;line-height:1.7;color:#444;}
  .exp-item{margin-bottom:14px;}
  .exp-role{font-size:14px;font-weight:600;}
  .exp-company{font-size:12px;color:#7C3AED;margin-bottom:4px;}
  .exp-desc{font-size:12px;color:#555;line-height:1.6;}
  @media print{body{-webkit-print-color-adjust:exact;print-color-adjust:exact;}}
</style></head><body>
<div class="page">
  <div class="sidebar">
    <div style="display:flex;flex-direction:column;align-items:center;text-align:center">
      ${photoHTML}
      <h1>${result.name}</h1>
      <div class="title">${result.jobTitle}</div>
    </div>
    <div class="sec">Контакты</div>
    <p>${result.contact?.split("|").join("<br/>")}</p>
    <div class="sec">Навыки</div>
    <div>${(result.skills || []).map(s => `<span class="skill-tag">${s}</span>`).join("")}</div>
  </div>
  <div class="main">
    <div class="sec-head">О себе</div>
    <p class="summary">${result.summary}</p>
    <div class="sec-head">Опыт работы</div>
    ${(result.experience || []).map(e => `
      <div class="exp-item">
        <div class="exp-role">${e.role}</div>
        <div class="exp-company">${e.company}</div>
        <div class="exp-desc">${e.desc}</div>
      </div>`).join("")}
    <div class="sec-head">Образование</div>
    <p class="summary">${result.education}</p>
  </div>
</div></body></html>`);
    win.document.close();
    setTimeout(() => win.print(), 600);
  };

  const set = (k, v) => setForm((p) => ({ ...p, [k]: v }));

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      {/* Language */}
      <div style={{ display: "flex", gap: 8 }}>
        {LANGUAGES.map((l) => (
          <button key={l.code} onClick={() => set("lang", l.code)} style={S.btnLang(form.lang === l.code)}>
            {l.label}
          </button>
        ))}
      </div>

      {/* Photo */}
      <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
        <div
          onClick={() => fileRef.current.click()}
          style={{
            width: 80, height: 80, borderRadius: "50%",
            border: "2px dashed #7C3AED",
            display: "flex", alignItems: "center", justifyContent: "center",
            cursor: "pointer", overflow: "hidden",
            background: "rgba(255,255,255,0.08)", flexShrink: 0,
          }}
        >
          {photoPreview
            ? <img src={photoPreview} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
            : <span style={{ fontSize: 30 }}>👤</span>}
        </div>
        <div>
          <p style={{ color: "rgba(255,255,255,0.85)", fontSize: 14, fontWeight: 500 }}>Фото профиля</p>
          <p style={{ color: "rgba(255,255,255,0.4)", fontSize: 12 }}>Нажми чтобы добавить</p>
        </div>
        <input ref={fileRef} type="file" accept="image/*" style={{ display: "none" }} onChange={handlePhoto} />
      </div>

      {/* Fields 2-column */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
        <input style={S.input} placeholder="Имя" value={form.firstName} onChange={e => set("firstName", e.target.value)} />
        <input style={S.input} placeholder="Фамилия" value={form.lastName} onChange={e => set("lastName", e.target.value)} />
        <input style={S.input} placeholder="Телефон" value={form.phone} onChange={e => set("phone", e.target.value)} />
        <input style={S.input} placeholder="Email" value={form.email} onChange={e => set("email", e.target.value)} />
        <input style={S.input} placeholder="Город" value={form.city} onChange={e => set("city", e.target.value)} />
        <input style={S.input} placeholder="Должность" value={form.jobTitle} onChange={e => set("jobTitle", e.target.value)} />
      </div>

      <input style={S.input} placeholder="Компания (последнее место работы)" value={form.company} onChange={e => set("company", e.target.value)} />
      <textarea style={S.textarea} rows={3} placeholder="Опыт работы (опишите что делали)" value={form.experience} onChange={e => set("experience", e.target.value)} />
      <input style={S.input} placeholder="Образование (вуз, специальность)" value={form.education} onChange={e => set("education", e.target.value)} />
      <input style={S.input} placeholder="Навыки (через запятую)" value={form.skills} onChange={e => set("skills", e.target.value)} />

      <button
        onClick={generate}
        disabled={loading || !form.firstName}
        style={loading || !form.firstName ? S.btnPrimaryDisabled : S.btnPrimary}
      >
        {loading ? "⏳ Генерирую резюме..." : "✨ Создать резюме"}
      </button>

      {result && !result.error && (
        <div style={S.card}>
          <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 12 }}>
            {photoPreview && (
              <img src={photoPreview} style={{ width: 56, height: 56, borderRadius: "50%", objectFit: "cover", border: "2px solid #7C3AED" }} />
            )}
            <div>
              <p style={{ color: "#fff", fontWeight: 700, fontSize: 18 }}>{result.name}</p>
              <p style={{ color: "#a78bfa", fontSize: 13 }}>{result.jobTitle}</p>
              <p style={{ color: "rgba(255,255,255,0.45)", fontSize: 12 }}>{result.contact}</p>
            </div>
          </div>
          <p style={{ color: "rgba(255,255,255,0.75)", fontSize: 13, lineHeight: 1.7, marginBottom: 12 }}>{result.summary}</p>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 14 }}>
            {(result.skills || []).map((s, i) => (
              <span key={i} style={{ background: "rgba(124,58,237,0.3)", color: "#c4b5fd", fontSize: 12, padding: "4px 12px", borderRadius: 999 }}>{s}</span>
            ))}
          </div>
          <button onClick={printResume}
            style={{ width: "100%", padding: "12px 0", borderRadius: 14, background: "#fff", color: "#7C3AED", fontWeight: 700, fontSize: 14, border: "none", cursor: "pointer" }}>
            📥 Скачать PDF
          </button>
        </div>
      )}
      {result?.error && <p style={{ color: "#f87171", fontSize: 13, textAlign: "center" }}>{result.error}</p>}
    </div>
  );
}

// ─── TRANSLATE ───────────────────────────────────────────────────────────────
function TranslateTool() {
  const [text, setText] = useState("");
  const [from, setFrom] = useState("ru");
  const [to, setTo] = useState("en");
  const [result, setResult] = useState("");
  const [loading, setLoading] = useState(false);

  const translate = async () => {
    if (!text.trim()) return;
    setLoading(true);
    setResult("");
    const langNames = { ru: "русский", uz: "узбекский (латиница)", en: "английский" };
    const res = await callClaude(
      `Переведи следующий текст с ${langNames[from]} на ${langNames[to]}. Верни только перевод, без пояснений:\n\n${text}`,
      "You are a professional translator. Return only the translated text."
    );
    setResult(res.trim());
    setLoading(false);
  };

  const swap = () => { setFrom(to); setTo(from); setResult(""); };

  const selectStyle = {
    flex: 1,
    background: "rgba(255,255,255,0.08)",
    border: "1px solid rgba(255,255,255,0.15)",
    borderRadius: 14,
    padding: "12px",
    color: "#fff",
    fontSize: 13,
    outline: "none",
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <select value={from} onChange={e => setFrom(e.target.value)} style={selectStyle}>
          {LANGUAGES.map(l => <option key={l.code} value={l.code} style={{ background: "#1a1a2e" }}>{l.label}</option>)}
        </select>
        <button onClick={swap} style={{ width: 40, height: 40, borderRadius: "50%", background: "rgba(124,58,237,0.3)", color: "#fff", border: "none", cursor: "pointer", fontSize: 18, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>⇄</button>
        <select value={to} onChange={e => setTo(e.target.value)} style={selectStyle}>
          {LANGUAGES.map(l => <option key={l.code} value={l.code} style={{ background: "#1a1a2e" }}>{l.label}</option>)}
        </select>
      </div>

      <textarea style={S.textarea} rows={5} placeholder="Введи текст для перевода..." value={text} onChange={e => setText(e.target.value)} />

      <button onClick={translate} disabled={loading || !text.trim()} style={loading || !text.trim() ? S.btnPrimaryDisabled : S.btnPrimary}>
        {loading ? "⏳ Перевожу..." : "🌐 Перевести"}
      </button>

      {result && (
        <div style={S.card}>
          <p style={{ color: "rgba(255,255,255,0.45)", fontSize: 11, marginBottom: 8, textTransform: "uppercase", letterSpacing: 1 }}>Перевод</p>
          <p style={{ color: "#fff", fontSize: 14, lineHeight: 1.7 }}>{result}</p>
          <button onClick={() => navigator.clipboard.writeText(result)}
            style={{ marginTop: 10, color: "#a78bfa", fontSize: 12, background: "none", border: "none", cursor: "pointer" }}>
            📋 Копировать
          </button>
        </div>
      )}
    </div>
  );
}

// ─── POEM ────────────────────────────────────────────────────────────────────
function PoemTool() {
  const [topic, setTopic] = useState("");
  const [lang, setLang] = useState("ru");
  const [result, setResult] = useState("");
  const [loading, setLoading] = useState(false);

  const generate = async () => {
    if (!topic.trim()) return;
    setLoading(true);
    setResult("");
    const langNames = { ru: "русском", uz: "узбекском (латиница)", en: "английском" };
    const res = await callClaude(
      `Напиши красивое лирическое стихотворение на ${langNames[lang]} языке на тему: "${topic}". 
Стихотворение должно быть 3-4 строфы, с красивыми рифмами, образным языком и глубоким смыслом. 
Верни только само стихотворение.`,
      "You are a talented poet. Write beautiful, emotional poetry."
    );
    setResult(res.trim());
    setLoading(false);
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      <div style={{ display: "flex", gap: 8 }}>
        {LANGUAGES.map((l) => (
          <button key={l.code} onClick={() => setLang(l.code)} style={S.btnLang(lang === l.code)}>{l.label}</button>
        ))}
      </div>

      <input style={S.input} placeholder="Тема стихотворения (любовь, природа, дружба...)" value={topic} onChange={e => setTopic(e.target.value)} />

      <button onClick={generate} disabled={loading || !topic.trim()} style={loading || !topic.trim() ? S.btnPrimaryDisabled : S.btnPrimary}>
        {loading ? "⏳ Пишу стихотворение..." : "✨ Написать стихотворение"}
      </button>

      {result && (
        <div style={S.card}>
          <pre style={{ color: "rgba(255,255,255,0.9)", fontSize: 14, lineHeight: 1.8, whiteSpace: "pre-wrap", fontFamily: "inherit" }}>{result}</pre>
          <button onClick={() => navigator.clipboard.writeText(result)}
            style={{ marginTop: 10, color: "#a78bfa", fontSize: 12, background: "none", border: "none", cursor: "pointer" }}>
            📋 Копировать
          </button>
        </div>
      )}
    </div>
  );
}

// ─── NAMES ───────────────────────────────────────────────────────────────────
function NamesTool() {
  const [dadName, setDadName] = useState("");
  const [momName, setMomName] = useState("");
  const [gender, setGender] = useState("boy");
  const [lang, setLang] = useState("ru");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const generate = async () => {
    setLoading(true);
    setResult(null);
    const genderLabel = gender === "boy" ? "мальчика" : "девочки";
    const langNames = { ru: "русском", uz: "узбекском", en: "английском" };
    const res = await callClaude(
      `Предложи 5 красивых имён для ${genderLabel}, родители которого: папа — ${dadName}, мама — ${momName}.
Верни ТОЛЬКО JSON без markdown:
[{"name":"Имя","meaning":"значение имени на ${langNames[lang]} языке","origin":"происхождение"}]

Имена должны быть красивыми, современными, подходящими для узбекской семьи. Ответ на ${langNames[lang]} языке.`,
      "You are a names expert. Return only valid JSON array, no markdown."
    );
    try {
      const clean = res.replace(/```json|```/g, "").trim();
      setResult(JSON.parse(clean));
    } catch {
      setResult([{ name: "Ошибка", meaning: "Попробуй снова", origin: "" }]);
    }
    setLoading(false);
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      <div style={{ display: "flex", gap: 8 }}>
        {LANGUAGES.map((l) => (
          <button key={l.code} onClick={() => setLang(l.code)} style={S.btnLang(lang === l.code)}>{l.label}</button>
        ))}
      </div>

      <div style={{ display: "flex", gap: 10 }}>
        <button onClick={() => setGender("boy")} style={{ flex: 1, padding: "12px 0", borderRadius: 18, background: gender === "boy" ? "#3B82F6" : "rgba(255,255,255,0.08)", color: "#fff", fontWeight: 700, fontSize: 14, border: "none", cursor: "pointer" }}>
          👦 Мальчик
        </button>
        <button onClick={() => setGender("girl")} style={{ flex: 1, padding: "12px 0", borderRadius: 18, background: gender === "girl" ? "#EC4899" : "rgba(255,255,255,0.08)", color: "#fff", fontWeight: 700, fontSize: 14, border: "none", cursor: "pointer" }}>
          👧 Девочка
        </button>
      </div>

      <input style={S.input} placeholder="Имя папы" value={dadName} onChange={e => setDadName(e.target.value)} />
      <input style={S.input} placeholder="Имя мамы" value={momName} onChange={e => setMomName(e.target.value)} />

      <button onClick={generate} disabled={loading || !dadName || !momName} style={loading || !dadName || !momName ? S.btnPrimaryDisabled : S.btnPrimary}>
        {loading ? "⏳ Подбираю имена..." : "✨ Найти имена"}
      </button>

      {result && (
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {result.map((item, i) => (
            <div key={i} style={{ ...S.card, display: "flex", alignItems: "flex-start", gap: 12 }}>
              <span style={{ fontSize: 28 }}>{gender === "boy" ? "👦" : "👧"}</span>
              <div>
                <p style={{ color: "#fff", fontWeight: 700, fontSize: 16 }}>{item.name}</p>
                <p style={{ color: "#a78bfa", fontSize: 12, marginTop: 2 }}>{item.origin}</p>
                <p style={{ color: "rgba(255,255,255,0.65)", fontSize: 13, marginTop: 4 }}>{item.meaning}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── MAIN ────────────────────────────────────────────────────────────────────
export default function SmartTools({ onBack }) {
  const [tab, setTab] = useState("resume");

  return (
    <div style={{
      minHeight: "100vh",
      background: "linear-gradient(135deg, #0f0c29 0%, #302b63 50%, #24243e 100%)",
      fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
      color: "#fff",
    }}>
      {/* Header */}
      <div style={{ padding: "32px 20px 16px" }}>
        {onBack && <button onClick={onBack} style={{ background: "rgba(255,255,255,0.08)", border: "1px solid rgba(255,255,255,0.15)", borderRadius: 10, padding: "6px 14px", color: "rgba(255,255,255,0.6)", fontSize: 13, cursor: "pointer", marginBottom: 12 }}>← Назад</button>}
        <h1 style={{ fontSize: 26, fontWeight: 900, margin: 0, letterSpacing: -0.5 }}>✦ Smart Tools</h1>
        <p style={{ color: "rgba(255,255,255,0.4)", fontSize: 13, marginTop: 4 }}>AI инструменты в одном месте</p>
      </div>

      {/* Tabs */}
      <div style={{ display: "flex", gap: 8, padding: "0 20px 16px", overflowX: "auto" }}>
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            style={{
              display: "flex", alignItems: "center", gap: 6,
              padding: "10px 16px",
              borderRadius: 18,
              background: tab === t.id ? "#7C3AED" : "rgba(255,255,255,0.08)",
              color: tab === t.id ? "#fff" : "rgba(255,255,255,0.55)",
              fontWeight: 600, fontSize: 13,
              border: "none", cursor: "pointer",
              whiteSpace: "nowrap", flexShrink: 0,
              boxShadow: tab === t.id ? "0 4px 20px rgba(124,58,237,0.4)" : "none",
            }}
          >
            <span>{t.icon}</span>
            <span>{t.label}</span>
          </button>
        ))}
      </div>

      {/* Content */}
      <div style={{ padding: "0 20px 40px" }}>
        {tab === "resume" && <ResumeTool />}
        {tab === "translate" && <TranslateTool />}
        {tab === "poem" && <PoemTool />}
        {tab === "names" && <NamesTool />}
      </div>
    </div>
  );
}
