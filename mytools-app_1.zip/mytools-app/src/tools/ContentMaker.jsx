import { useState } from "react";

const PLATFORM_OPTIONS = [
  { id: "ig-reels", label: "Instagram Reels", icon: "🎬", color: "#E1306C" },
  { id: "ig-stories", label: "Instagram Stories", icon: "📱", color: "#F77737" },
  { id: "yt-shorts", label: "YouTube Shorts", icon: "⚡", color: "#FF0000" },
  { id: "yt-long", label: "YouTube Видео", icon: "🎥", color: "#CC0000" },
  { id: "ig-zero", label: "Instagram с нуля", icon: "🌱", color: "#833AB4" },
  { id: "yt-zero", label: "YouTube с нуля", icon: "🚀", color: "#FF6B35" },
];

const CATEGORY_OPTIONS = [
  "ibratli video", "motivation", "lifestyle", "biznes", "ta'lim",
  "ko'ngilochar", "sport", "ovqat", "sayohat", "texnologiya",
  "moda", "psixologiya", "pul ishlash", "oila"
];

const TREND_SOURCES = [
  { id: "trend-ig", label: "🔥 Trendlar Instagram", platform: "Instagram" },
  { id: "trend-yt", label: "🔥 Trendlar YouTube", platform: "YouTube" },
];

function LoadingDots() {
  return (
    <div style={{ display: "flex", gap: "6px", alignItems: "center", justifyContent: "center", padding: "12px 0" }}>
      {[0, 1, 2].map(i => (
        <div key={i} style={{
          width: 8, height: 8, borderRadius: "50%", background: "#C8F135",
          animation: `bounce 1.2s ease-in-out ${i * 0.2}s infinite`,
        }} />
      ))}
      <style>{`@keyframes bounce { 0%,80%,100%{transform:translateY(0)} 40%{transform:translateY(-10px)} }`}</style>
    </div>
  );
}

export default function ContentMaker({ onBack }) {
  const [platform, setPlatform] = useState(null);
  const [trendMode, setTrendMode] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [customTopic, setCustomTopic] = useState("");
  const [script, setScript] = useState(null);
  const [loading, setLoading] = useState(false);
  const [trendLoading, setTrendLoading] = useState(false);
  const [trendInfo, setTrendInfo] = useState(null);
  const [step, setStep] = useState(1); // 1=platform, 2=topic, 3=script

  const selectedPlatformObj = PLATFORM_OPTIONS.find(p => p.id === platform);

  async function analyzeTrends(source) {
    setTrendMode(source.id);
    setTrendLoading(true);
    setTrendInfo(null);

    const response = await fetch("/api/ai", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1000,
        tools: [{ type: "web_search_20250305", name: "web_search" }],
        messages: [{
          role: "user",
          content: `Проанализируй что сейчас в тренде на ${source.platform} в Узбекистане и в мире в 2025-2026 году. Найди самые популярные форматы видео, темы и хэштеги. Дай список из 5-7 горячих трендов с кратким объяснением каждого. Отвечай на русском языке. Будь конкретным и актуальным.`
        }]
      })
    });

    const data = await response.json();
    const text = data.content.filter(b => b.type === "text").map(b => b.text).join("\n");
    setTrendInfo({ source: source.platform, text });
    setTrendLoading(false);
    setStep(2);
  }

  async function generateScript() {
    if (!platform) return;
    const topic = customTopic.trim() || selectedCategory;
    if (!topic) return;

    setLoading(true);
    setScript(null);
    setStep(3);

    const platformObj = PLATFORM_OPTIONS.find(p => p.id === platform);
    const platformName = platformObj?.label || platform;
    const trendContext = trendInfo ? `\n\nАктуальные тренды на ${trendInfo.source}:\n${trendInfo.text}` : "";

    const prompt = `Ты профессиональный сценарист для социальных сетей. Создай детальный сценарий видео для платформы ${platformName}.

Тема: "${topic}"
Аудитория: Узбекистан (узбекская и русскоязычная аудитория)${trendContext}

Требования к сценарию:
- Платформа: ${platformName}
- Тема популярная и актуальная
- Сценарий должен быть ПОДРОБНЫМ и ПРОФЕССИОНАЛЬНЫМ
- Укажи хронометраж каждой части
- Чётко пиши что говорит персонаж (дословно)
- Укажи визуальные инструкции (что показывать на экране)
- Добавь хуки (зацепки) в начале
- Призыв к действию в конце
- Используй формат: [ВРЕМЯ] ПЕРСОНАЖ: "текст" | 🎬 Видеоряд: описание

Структура:
1. ХУК (первые 3 секунды) - зацепи зрителя
2. ВВЕДЕНИЕ - о чём видео
3. ОСНОВНАЯ ЧАСТЬ - детальный контент
4. ЗАКЛЮЧЕНИЕ - вывод
5. ПРИЗЫВ К ДЕЙСТВИЮ - подписка/лайк/комментарий

Пиши на русском языке. Сценарий должен быть не менее 400-500 слов.`;

    const response = await fetch("/api/ai", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1000,
        messages: [{ role: "user", content: prompt }]
      })
    });

    const data = await response.json();
    const text = data.content.map(b => b.text || "").join("\n");
    setScript({ topic, platform: platformName, text });
    setLoading(false);
  }

  function reset() {
    setPlatform(null); setTrendMode(null); setSelectedCategory(null);
    setCustomTopic(""); setScript(null); setTrendInfo(null); setStep(1);
  }

  const canGenerate = platform && (customTopic.trim() || selectedCategory);

  return (
    <div style={{
      minHeight: "100vh",
      background: "#0A0A0A",
      fontFamily: "'Syne', 'Space Grotesk', sans-serif",
      color: "#F0F0E8",
      position: "relative",
      overflow: "hidden",
    }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&display=swap');
        * { box-sizing: border-box; }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-track { background: #111; }
        ::-webkit-scrollbar-thumb { background: #C8F135; border-radius: 2px; }
        .btn-platform {
          background: #111; border: 1.5px solid #2a2a2a; border-radius: 12px;
          padding: 14px 18px; cursor: pointer; transition: all 0.2s;
          display: flex; align-items: center; gap: 10px; color: #F0F0E8;
          font-family: inherit; font-size: 14px; font-weight: 600;
          text-align: left; width: 100%;
        }
        .btn-platform:hover { border-color: #C8F135; background: #1a1a0a; transform: translateY(-1px); }
        .btn-platform.active { border-color: #C8F135; background: #1a1f00; }
        .btn-cat {
          background: #111; border: 1.5px solid #222; border-radius: 8px;
          padding: 8px 14px; cursor: pointer; transition: all 0.2s;
          color: #aaa; font-family: inherit; font-size: 13px; font-weight: 600;
          white-space: nowrap;
        }
        .btn-cat:hover { border-color: #C8F135; color: #C8F135; }
        .btn-cat.active { border-color: #C8F135; background: #1a1f00; color: #C8F135; }
        .btn-trend {
          background: linear-gradient(135deg, #1a0f00, #0f1a00); border: 1.5px solid #ff6b35;
          border-radius: 10px; padding: 12px 18px; cursor: pointer; transition: all 0.2s;
          color: #ff6b35; font-family: inherit; font-size: 13px; font-weight: 700;
          white-space: nowrap;
        }
        .btn-trend:hover { background: linear-gradient(135deg, #2a1800, #1a2a00); transform: translateY(-2px); box-shadow: 0 4px 20px #ff6b3540; }
        .btn-trend.active { border-color: #C8F135; color: #C8F135; background: #0f1a00; }
        .btn-generate {
          background: #C8F135; border: none; border-radius: 12px; padding: 16px 32px;
          cursor: pointer; font-family: inherit; font-size: 16px; font-weight: 800;
          color: #0A0A0A; transition: all 0.2s; letter-spacing: -0.3px;
          width: 100%;
        }
        .btn-generate:hover { background: #d4ff40; transform: translateY(-2px); box-shadow: 0 8px 30px #C8F13550; }
        .btn-generate:disabled { opacity: 0.3; cursor: not-allowed; transform: none; box-shadow: none; }
        .script-box {
          background: #0f0f0f; border: 1px solid #222; border-radius: 16px; padding: 28px;
          white-space: pre-wrap; line-height: 1.8; font-size: 14px; color: #ddd;
          font-family: 'Courier New', monospace; max-height: 500px; overflow-y: auto;
        }
        .section-title {
          font-size: 11px; font-weight: 800; letter-spacing: 2px; color: #C8F135;
          text-transform: uppercase; margin-bottom: 12px;
        }
        .trend-box {
          background: #0f1400; border: 1px solid #2a3300; border-radius: 12px;
          padding: 20px; font-size: 13px; line-height: 1.7; color: #ccc;
          max-height: 200px; overflow-y: auto; white-space: pre-wrap;
        }
        .badge {
          display: inline-block; background: #C8F13520; border: 1px solid #C8F13540;
          color: #C8F135; padding: 4px 10px; border-radius: 20px; font-size: 11px;
          font-weight: 700; letter-spacing: 1px; text-transform: uppercase;
        }
        textarea {
          background: #111; border: 1.5px solid #2a2a2a; border-radius: 10px;
          padding: 14px; color: #F0F0E8; font-family: inherit; font-size: 14px;
          width: 100%; resize: none; outline: none; transition: border-color 0.2s;
        }
        textarea:focus { border-color: #C8F135; }
        textarea::placeholder { color: #444; }
        .step-indicator {
          display: flex; gap: 8px; align-items: center; margin-bottom: 32px;
        }
        .step-dot {
          width: 8px; height: 8px; border-radius: 50%;
          transition: all 0.3s;
        }
      `}</style>

      {/* BG glow */}
      <div style={{ position: "fixed", top: -200, right: -200, width: 500, height: 500, borderRadius: "50%", background: "radial-gradient(circle, #C8F13510 0%, transparent 70%)", pointerEvents: "none" }} />
      <div style={{ position: "fixed", bottom: -200, left: -200, width: 400, height: 400, borderRadius: "50%", background: "radial-gradient(circle, #ff6b3508 0%, transparent 70%)", pointerEvents: "none" }} />

      <div style={{ maxWidth: 700, margin: "0 auto", padding: "40px 20px 80px" }}>

        {/* Header */}
        <div style={{ marginBottom: 40 }}>
          {onBack && <button onClick={onBack} style={{ background: "none", border: "1px solid #333", borderRadius: 8, padding: "6px 14px", color: "#666", cursor: "pointer", fontSize: 13, fontFamily: "inherit", marginBottom: 16 }}>← Orqaga</button>}
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
            <div>
              <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: 3, color: "#C8F135", marginBottom: 8 }}>AI CONTENT MAKER</div>
              <h1 style={{ margin: 0, fontSize: 36, fontWeight: 800, letterSpacing: -1.5, lineHeight: 1.1, color: "#F0F0E8" }}>
                Ssenariy<br /><span style={{ color: "#C8F135" }}>Generator</span>
              </h1>
            </div>
            {(platform || script) && (
              <button onClick={reset} style={{ background: "none", border: "1px solid #333", borderRadius: 8, padding: "8px 16px", color: "#666", cursor: "pointer", fontSize: 13, fontFamily: "inherit" }}>
                ↺ Qayta
              </button>
            )}
          </div>

          {/* Step dots */}
          <div className="step-indicator">
            {[1,2,3].map(s => (
              <div key={s} className="step-dot" style={{
                background: step >= s ? "#C8F135" : "#222",
                width: step === s ? 24 : 8,
                borderRadius: step === s ? 4 : "50%",
              }} />
            ))}
            <span style={{ fontSize: 12, color: "#444", marginLeft: 4 }}>
              {step === 1 ? "Platforma tanlang" : step === 2 ? "Mavzu tanlang" : "Ssenariy"}
            </span>
          </div>
        </div>

        {/* STEP 1: Platform Selection */}
        <div style={{ marginBottom: 32 }}>
          <div className="section-title">1 — Platforma</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            {PLATFORM_OPTIONS.map(p => (
              <button
                key={p.id}
                className={`btn-platform ${platform === p.id ? "active" : ""}`}
                onClick={() => { setPlatform(p.id); if (step < 2) setStep(2); }}
              >
                <span style={{ fontSize: 20 }}>{p.icon}</span>
                <span>{p.label}</span>
                {platform === p.id && <span style={{ marginLeft: "auto", color: "#C8F135" }}>✓</span>}
              </button>
            ))}
          </div>
        </div>

        {/* STEP 2: Topic & Trends */}
        {step >= 2 && (
          <div style={{ marginBottom: 32 }}>
            <div className="section-title">2 — Mavzu</div>

            {/* Trend buttons */}
            <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 16 }}>
              {TREND_SOURCES.map(src => (
                <button
                  key={src.id}
                  className={`btn-trend ${trendMode === src.id ? "active" : ""}`}
                  onClick={() => analyzeTrends(src)}
                  disabled={trendLoading}
                >
                  {src.label}
                </button>
              ))}
            </div>

            {trendLoading && (
              <div style={{ background: "#0f1400", border: "1px solid #2a3300", borderRadius: 12, padding: 20, marginBottom: 16 }}>
                <div style={{ fontSize: 12, color: "#C8F135", marginBottom: 8 }}>🔍 Trendlar analizlanmoqda...</div>
                <LoadingDots />
              </div>
            )}

            {trendInfo && (
              <div style={{ marginBottom: 16 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
                  <span style={{ fontSize: 12, color: "#888" }}>🔥 Hozirgi trendlar — {trendInfo.source}</span>
                  <span className="badge">Real vaqt</span>
                </div>
                <div className="trend-box">{trendInfo.text}</div>
              </div>
            )}

            {/* Category pills */}
            <div style={{ marginBottom: 14 }}>
              <div style={{ fontSize: 12, color: "#555", marginBottom: 10 }}>Kategoriya tanlang:</div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                {CATEGORY_OPTIONS.map(cat => (
                  <button
                    key={cat}
                    className={`btn-cat ${selectedCategory === cat ? "active" : ""}`}
                    onClick={() => { setSelectedCategory(cat === selectedCategory ? null : cat); setCustomTopic(""); }}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Custom topic */}
            <div style={{ marginBottom: 4 }}>
              <div style={{ fontSize: 12, color: "#555", marginBottom: 8 }}>Yoki o'z mavzungizni yozing:</div>
              <textarea
                rows={2}
                placeholder="Masalan: 30 kunda 1 million so'm tejash usullari..."
                value={customTopic}
                onChange={e => { setCustomTopic(e.target.value); setSelectedCategory(null); }}
              />
            </div>

            {/* Generate button */}
            <div style={{ marginTop: 20 }}>
              <button
                className="btn-generate"
                onClick={generateScript}
                disabled={!canGenerate || loading}
              >
                {loading ? "⏳ Ssenariy yaratilmoqda..." : "✨ Ssenariy yaratish"}
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: Script */}
        {step >= 3 && (
          <div style={{ marginTop: 32 }}>
            <div className="section-title">3 — Ssenariy</div>

            {loading && (
              <div style={{ background: "#0f0f0f", border: "1px solid #1a1a1a", borderRadius: 16, padding: 40, textAlign: "center" }}>
                <div style={{ fontSize: 14, color: "#C8F135", marginBottom: 8 }}>🧠 Ssenariy yozilmoqda...</div>
                <LoadingDots />
                <div style={{ fontSize: 12, color: "#444", marginTop: 8 }}>
                  {platform && `${selectedPlatformObj?.label} uchun`} professonal ssenariy tayyorlanmoqda
                </div>
              </div>
            )}

            {script && !loading && (
              <div>
                <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 16 }}>
                  <span className="badge">{script.platform}</span>
                  <span style={{ fontSize: 13, color: "#666" }}>— {script.topic}</span>
                </div>
                <div className="script-box">{script.text}</div>
                <div style={{ display: "flex", gap: 10, marginTop: 16 }}>
                  <button
                    onClick={() => navigator.clipboard.writeText(script.text)}
                    style={{ flex: 1, background: "#1a1a1a", border: "1px solid #333", borderRadius: 10, padding: "12px", color: "#aaa", cursor: "pointer", fontFamily: "inherit", fontSize: 13, fontWeight: 600 }}
                  >
                    📋 Nusxa ko'chirish
                  </button>
                  <button
                    onClick={generateScript}
                    style={{ flex: 1, background: "#1a1f00", border: "1px solid #C8F13550", borderRadius: 10, padding: "12px", color: "#C8F135", cursor: "pointer", fontFamily: "inherit", fontSize: 13, fontWeight: 600 }}
                  >
                    🔄 Yangi variant
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
