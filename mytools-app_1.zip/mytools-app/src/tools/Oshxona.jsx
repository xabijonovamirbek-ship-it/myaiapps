import { useState, useEffect } from "react";

const categories = [
  {
    id: "quruq",
    emoji: "🥩",
    title: "Қуруқ таом",
    subtitle: "Мясо, жаркое, плов",
    accent: "#C0392B",
    cookingMethods: ["Казан", "Сковородка", "Духовка", "Гриль"],
    examples: "мясо, морковь, лук, рис, масло...",
  },
  {
    id: "suyuq",
    emoji: "🍲",
    title: "Суюқ таом",
    subtitle: "Шурпа, мастава, лагман",
    accent: "#D68910",
    cookingMethods: ["Казан", "Кастрюля", "Скороварка"],
    examples: "мясо, картошка, морковь, лук, помидор...",
  },
  {
    id: "testo",
    emoji: "🥟",
    title: "Хамир таомлар",
    subtitle: "Манты, чучвара, самса",
    accent: "#8E44AD",
    cookingMethods: ["Мантоварка", "Казан (фритюр)", "Духовка", "Сковородка"],
    examples: "мука, мясо, лук, масло, яйцо...",
  },
  {
    id: "shirinlik",
    emoji: "🍰",
    title: "Ширинликлар",
    subtitle: "Выпечка, десерты, сладости",
    accent: "#B9770E",
    cookingMethods: ["Духовка", "Сковородка", "Казан", "Микроволновка"],
    examples: "мука, сахар, масло, яйца, ванилин, катык...",
    subtypes: [
      { id: "pechenye", label: "Печенье", emoji: "🍪" },
      { id: "pirojnoe", label: "Пирожное", emoji: "🧁" },
    ],
  },
];

const styles = `
  @import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700;9..144,900&family=Nunito:wght@400;600;700;800;900&display=swap');

  * { box-sizing: border-box; margin: 0; padding: 0; }

  :root {
    --bg: #FBF6EF;
    --bg-soft: #F3EADC;
    --surface: #FFFFFF;
    --surface-soft: #FFFCF7;
    --ink: #2A1B12;
    --ink-soft: #6B5847;
    --ink-faint: #A8957F;
    --border: #E9DCC8;
    --line: #EFE3D1;
    --header-grad-a: #2A1B12;
    --header-grad-b: #6B3420;
    --terra: #C0392B;
    --shadow: rgba(60, 35, 15, 0.10);
    --shadow-strong: rgba(60, 35, 15, 0.18);
  }

  [data-theme="dark"] {
    --bg: #19120C;
    --bg-soft: #241910;
    --surface: #261A12;
    --surface-soft: #2C1F15;
    --ink: #F4E9DC;
    --ink-soft: #C9B6A1;
    --ink-faint: #8A7461;
    --border: #3C2C1D;
    --line: #382A1C;
    --header-grad-a: #0E0905;
    --header-grad-b: #3C1C10;
    --terra: #E0604C;
    --shadow: rgba(0, 0, 0, 0.35);
    --shadow-strong: rgba(0, 0, 0, 0.5);
  }

  body {
    font-family: 'Nunito', sans-serif;
    background: var(--bg);
    min-height: 100vh;
    transition: background 0.3s ease;
  }

  .app {
    max-width: 480px;
    margin: 0 auto;
    padding: 0 0 40px;
    position: relative;
  }

  .header {
    background: linear-gradient(135deg, var(--header-grad-a) 0%, var(--header-grad-b) 100%);
    padding: 24px 20px 26px;
    text-align: center;
    position: relative;
    overflow: hidden;
  }

  .header::before {
    content: '';
    position: absolute;
    top: -40px; right: -40px;
    width: 140px; height: 140px;
    background: radial-gradient(circle, rgba(255,255,255,0.05), transparent 70%);
    border-radius: 50%;
  }

  .header::after {
    content: '';
    position: absolute;
    inset: 0;
    background-image:
      radial-gradient(circle at 10% 90%, rgba(255,255,255,0.04) 0%, transparent 8%),
      radial-gradient(circle at 85% 15%, rgba(255,255,255,0.03) 0%, transparent 10%);
    pointer-events: none;
  }

  .theme-toggle {
    position: absolute;
    top: 16px; right: 16px;
    width: 38px; height: 38px;
    border-radius: 50%;
    border: 1.5px solid rgba(255,255,255,0.25);
    background: rgba(255,255,255,0.08);
    color: #fff;
    font-size: 16px;
    display: flex; align-items: center; justify-content: center;
    cursor: pointer;
    transition: all 0.2s;
    z-index: 2;
  }

  .theme-toggle:active { transform: scale(0.9); background: rgba(255,255,255,0.18); }

  .header-emoji {
    font-size: 34px;
    margin-bottom: 6px;
    display: block;
    position: relative;
    z-index: 1;
  }

  .header h1 {
    font-family: 'Fraunces', serif;
    font-size: 24px;
    font-weight: 700;
    font-style: italic;
    color: #FFF;
    letter-spacing: -0.2px;
    position: relative;
    z-index: 1;
  }

  .header p {
    font-size: 13px;
    color: rgba(255,255,255,0.62);
    margin-top: 5px;
    font-weight: 600;
    position: relative;
    z-index: 1;
  }

  .step-bar {
    display: flex;
    align-items: center;
    padding: 16px 20px;
    gap: 0;
  }

  .step-dot {
    width: 26px; height: 26px;
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    font-size: 11px; font-weight: 800;
    background: var(--bg-soft);
    color: var(--ink-faint);
    flex-shrink: 0;
    transition: all 0.3s;
  }

  .step-dot.active { background: var(--ink); color: var(--bg); }
  .step-dot.done { background: #5B8C5A; color: #fff; }

  [data-theme="dark"] .step-dot.done { background: #6FA66D; }

  .step-line {
    flex: 1;
    height: 2px;
    background: var(--bg-soft);
    transition: background 0.3s;
  }

  .step-line.done { background: #5B8C5A; }

  .section { padding: 0 20px; }

  .section-title {
    font-size: 12.5px;
    font-weight: 800;
    color: var(--ink-faint);
    text-transform: uppercase;
    letter-spacing: 1.2px;
    margin: 22px 0 12px;
    display: flex;
    align-items: baseline;
    gap: 6px;
  }

  .section-title .num {
    font-family: 'Fraunces', serif;
    font-style: italic;
    font-size: 15px;
    color: var(--terra);
    text-transform: none;
    letter-spacing: 0;
  }

  .cat-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
  }

  .cat-card {
    border-radius: 16px;
    padding: 18px 14px;
    cursor: pointer;
    border: 2px solid var(--border);
    background: var(--surface-soft);
    transition: all 0.2s;
    position: relative;
    overflow: hidden;
  }

  .cat-card:active { transform: scale(0.97); }

  .cat-card.selected {
    border-color: var(--cat-color);
    box-shadow: 0 4px 16px var(--shadow);
    background: var(--surface);
  }

  .cat-emoji { font-size: 30px; display: block; margin-bottom: 8px; }

  .cat-name {
    font-size: 14px;
    font-weight: 800;
    line-height: 1.2;
    margin-bottom: 3px;
    color: var(--ink);
  }

  .cat-sub {
    font-size: 11px;
    font-weight: 600;
    color: var(--ink-faint);
  }

  .check-badge {
    position: absolute;
    top: 10px; right: 10px;
    width: 20px; height: 20px;
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    font-size: 11px;
    color: white;
  }

  .card {
    background: var(--surface);
    border-radius: 16px;
    padding: 16px;
    box-shadow: 0 2px 8px var(--shadow);
    border: 1px solid var(--line);
  }

  textarea {
    width: 100%;
    border: 2px solid var(--border);
    border-radius: 12px;
    padding: 14px;
    font-family: 'Nunito', sans-serif;
    font-size: 15px;
    font-weight: 600;
    color: var(--ink);
    background: var(--surface-soft);
    resize: none;
    outline: none;
    transition: border-color 0.2s;
    min-height: 96px;
  }

  textarea:focus { border-color: var(--terra); }

  textarea::placeholder { color: var(--ink-faint); font-weight: 600; }

  .hint-text {
    font-size: 12px;
    color: var(--ink-faint);
    font-weight: 600;
    margin-top: 8px;
    padding-left: 2px;
  }

  .method-hint {
    font-size: 12.5px;
    color: var(--ink-soft);
    font-weight: 600;
    margin-bottom: 12px;
    line-height: 1.5;
  }

  .methods-grid {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
  }

  .method-btn {
    padding: 9px 16px;
    border-radius: 100px;
    border: 2px solid var(--border);
    background: var(--surface-soft);
    font-family: 'Nunito', sans-serif;
    font-size: 13px;
    font-weight: 700;
    color: var(--ink-soft);
    cursor: pointer;
    transition: all 0.2s;
    display: flex;
    align-items: center;
    gap: 6px;
  }

  .method-btn .order-pill {
    background: rgba(255,255,255,0.25);
    border-radius: 50%;
    width: 16px; height: 16px;
    font-size: 10px;
    display: flex; align-items: center; justify-content: center;
    font-weight: 800;
  }

  .method-btn.selected {
    border-color: var(--ink);
    background: var(--ink);
    color: var(--bg);
  }

  .method-btn.any.selected {
    border-color: var(--terra);
    background: var(--terra);
    color: #fff;
  }

  .method-btn:active { transform: scale(0.95); }

  .compare-note {
    display: flex;
    gap: 8px;
    align-items: flex-start;
    margin-top: 14px;
    padding: 10px 12px;
    background: var(--bg-soft);
    border-radius: 10px;
    font-size: 12.5px;
    font-weight: 600;
    color: var(--ink-soft);
    line-height: 1.5;
  }

  .compare-note .ico { font-size: 14px; flex-shrink: 0; margin-top: 1px; }

  .btn-main {
    width: 100%;
    padding: 16px;
    border-radius: 14px;
    border: none;
    background: linear-gradient(135deg, var(--header-grad-a), var(--header-grad-b));
    color: #fff;
    font-family: 'Nunito', sans-serif;
    font-size: 16px;
    font-weight: 800;
    cursor: pointer;
    transition: all 0.2s;
    margin-top: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
  }

  .btn-main:active { transform: scale(0.98); opacity: 0.9; }

  .btn-main:disabled {
    opacity: 0.4;
    cursor: not-allowed;
    transform: none;
  }

  .spinner {
    width: 18px; height: 18px;
    border: 3px solid rgba(255,255,255,0.3);
    border-top-color: white;
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
  }

  @keyframes spin { to { transform: rotate(360deg); } }

  .result-card {
    background: var(--surface);
    border-radius: 20px;
    overflow: hidden;
    box-shadow: 0 4px 20px var(--shadow-strong);
    border: 1px solid var(--line);
  }

  .result-header {
    padding: 22px 20px;
    color: white;
    position: relative;
    overflow: hidden;
  }

  .result-header::before {
    content: '🍴';
    position: absolute;
    font-size: 80px;
    opacity: 0.08;
    right: -10px;
    bottom: -20px;
    transform: rotate(-15deg);
  }

  .result-header h2 {
    font-family: 'Fraunces', serif;
    font-size: 21px;
    font-weight: 700;
    margin-bottom: 4px;
    position: relative;
  }

  .result-header p {
    font-size: 13px;
    opacity: 0.85;
    font-weight: 600;
    position: relative;
  }

  .result-body {
    padding: 20px;
  }

  .result-text {
    font-size: 15px;
    line-height: 1.7;
    color: var(--ink);
    font-weight: 600;
    white-space: pre-wrap;
  }

  .tag-row {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
    margin-top: 16px;
    padding-top: 16px;
    border-top: 1px solid var(--line);
  }

  .tag {
    padding: 6px 12px;
    border-radius: 100px;
    font-size: 12px;
    font-weight: 700;
    background: var(--bg-soft);
    color: var(--ink-soft);
  }

  .btn-reset {
    width: 100%;
    padding: 14px;
    border-radius: 14px;
    border: 2px solid var(--border);
    background: var(--surface);
    font-family: 'Nunito', sans-serif;
    font-size: 15px;
    font-weight: 700;
    color: var(--ink-soft);
    cursor: pointer;
    margin-top: 12px;
    transition: all 0.2s;
  }

  .btn-reset:active { background: var(--bg-soft); }

  .error-box {
    background: ${'#FEF0F0'};
    border: 2px solid #FCCACA;
    border-radius: 12px;
    padding: 14px;
    font-size: 14px;
    font-weight: 700;
    color: #C0392B;
    margin-top: 12px;
  }

  [data-theme="dark"] .error-box {
    background: #2E1414;
    border-color: #5A2424;
    color: #F2998C;
  }

  .loading-line {
    font-size: 12.5px;
    color: var(--ink-faint);
    font-weight: 600;
    text-align: center;
    margin-top: 10px;
    font-style: italic;
  }
`;

const loadingPhrases = [
  "Перебираю рецепты бабушки...",
  "Прикидываю, что войдёт в казан...",
  "Сверяюсь со специями...",
  "Почти готово, ещё щепотка...",
];

export default function Oshxona({ onBack }) {
  const [theme, setTheme] = useState("light");
  const [step, setStep] = useState(1);
  const [selectedCat, setSelectedCat] = useState(null);
  const [selectedSubtypes, setSelectedSubtypes] = useState([]);
  const [ingredients, setIngredients] = useState("");
  const [selectedMethods, setSelectedMethods] = useState([]);
  const [loading, setLoading] = useState(false);
  const [loadingPhrase, setLoadingPhrase] = useState(loadingPhrases[0]);
  const [result, setResult] = useState(null);
  const [previousDishes, setPreviousDishes] = useState([]);
  const [error, setError] = useState(null);

  const cat = categories.find((c) => c.id === selectedCat);

  const canProceedStep2 = ingredients.trim().length > 2;
  const canGenerate = canProceedStep2;

  useEffect(() => {
    if (!loading) return;
    let i = 0;
    const id = setInterval(() => {
      i = (i + 1) % loadingPhrases.length;
      setLoadingPhrase(loadingPhrases[i]);
    }, 1400);
    return () => clearInterval(id);
  }, [loading]);

  function toggleTheme() {
    setTheme((t) => (t === "light" ? "dark" : "light"));
  }

  function toggleMethod(m) {
    setSelectedMethods((prev) =>
      prev.includes(m) ? prev.filter((x) => x !== m) : [...prev, m]
    );
  }

  function toggleSubtype(id) {
    setSelectedSubtypes((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  }

  function buildSubtypeText() {
    if (!cat || !cat.subtypes || cat.subtypes.length === 0) return "";
    if (selectedSubtypes.length === 0) return "";
    const labels = cat.subtypes
      .filter((s) => selectedSubtypes.includes(s.id))
      .map((s) => s.label);
    if (labels.length === 1) return `Хочу именно: ${labels[0]}.`;
    return `Интересны оба варианта: ${labels.join(" и ")}. Предложи отдельно вариант для каждого и явно подпиши, где что (например: "Печенье:" и "Пирожное:").`;
  }

  function buildMethodText() {
    if (selectedMethods.length === 0) return "Способ приготовления: любой доступный, выбери сам, что подходит лучше.";
    if (selectedMethods.length === 1) return `Способ приготовления: ${selectedMethods[0]}.`;
    return `На выбор есть несколько способов приготовления: ${selectedMethods.join(", ")}. Предложи варианты под разные способы и явно укажи в начале каждого варианта, для какого способа он подходит (например: "Для духовки:" или "Для казана:"), чтобы было сразу понятно, что готовить чем.`;
  }

  async function generateIdea() {
    setLoading(true);
    setError(null);

    const subtypeText = buildSubtypeText();
    const avoidText =
      previousDishes.length > 0
        ? `\nВажно: раньше для этого набора ингредиентов уже предлагались блюда — ${previousDishes.join(
            ", "
          )}. Сейчас обязательно предложи что-то ДРУГОЕ, не повторяй эти варианты и не используй похожую формулировку названия.`
        : "";

    const prompt = `Ты тёплый, опытный кулинарный помощник, который разговаривает по-домашнему — как соседка с богатым опытом готовки, а не справочник. Специализация: узбекская и домашняя кухня.

Раздел кухни: ${cat.title} (${cat.subtitle})
${subtypeText}
Доступные ингредиенты: ${ingredients}
${buildMethodText()}${avoidText}

Предложи 1-2 конкретных блюда, которые можно приготовить. Для каждого блюда дай:
1. Название блюда (большими буквами), и если способов приготовления или вариантов несколько — пометку, к какому варианту относится
2. Тёплое, живое объяснение, почему это блюдо отлично ляжет на эти ингредиенты (1-2 предложения, без сухости, как будто советуешь другу)
3. Краткий пошаговый рецепт (5-7 шагов, по-человечески, без канцелярита)
4. Маленький секрет или совет от шефа (1 предложение)

Пиши на русском языке, простым тёплым языком, без формальностей и канцелярских оборотов. Будь конкретным и практичным.`;

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 25000);

    try {
      const response = await fetch("/api/ai", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 1200,
          messages: [{ role: "user", content: prompt }],
        }),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        setError(`Сервер ответил с ошибкой (${response.status}). Попробуй ещё раз.`);
        return;
      }

      const data = await response.json();
      const text = data?.content?.[0]?.text;

      if (text) {
        setResult(text);
        const titleMatch = text.match(/[A-ZА-ЯЁ][A-ZА-ЯЁ\s]{3,40}/);
        if (titleMatch) {
          setPreviousDishes((prev) => [...prev, titleMatch[0].trim()].slice(-5));
        }
        setStep(4);
      } else {
        setError("Что-то пошло не так. Попробуй ещё раз.");
      }
    } catch (e) {
      clearTimeout(timeoutId);
      if (e.name === "AbortError") {
        setError("Долго нет ответа от сервера. Попробуй ещё раз.");
      } else {
        setError("Не получилось связаться с сервером. Проверь интернет.");
      }
    } finally {
      setLoading(false);
    }
  }

  function reset() {
    setStep(1);
    setSelectedCat(null);
    setSelectedSubtypes([]);
    setIngredients("");
    setSelectedMethods([]);
    setResult(null);
    setPreviousDishes([]);
    setError(null);
  }

  return (
    <>
      <style>{styles}</style>
      <div className="app" data-theme={theme}>
        {/* Header */}
        <div className="header">
          {onBack && <button onClick={onBack} style={{ position: "absolute", top: 16, left: 16, background: "rgba(0,0,0,0.15)", border: "1px solid rgba(255,255,255,0.2)", borderRadius: 8, padding: "6px 14px", color: "rgba(255,255,255,0.8)", cursor: "pointer", fontSize: 13 }}>← Назад</button>}
          <button
            className="theme-toggle"
            onClick={toggleTheme}
            aria-label="Переключить тему"
          >
            {theme === "light" ? "🌙" : "☀️"}
          </button>
          <span className="header-emoji">🍽️</span>
          <h1>Ошхона Ёрдамчи</h1>
          <p>Что приготовить из того, что есть?</p>
        </div>

        {/* Step bar */}
        <div className="step-bar">
          <div className={`step-dot ${step > 1 ? "done" : step === 1 ? "active" : ""}`}>
            {step > 1 ? "✓" : "1"}
          </div>
          <div className={`step-line ${step > 1 ? "done" : ""}`} />
          <div className={`step-dot ${step > 2 ? "done" : step === 2 ? "active" : ""}`}>
            {step > 2 ? "✓" : "2"}
          </div>
          <div className={`step-line ${step > 2 ? "done" : ""}`} />
          <div className={`step-dot ${step > 3 ? "done" : step === 3 ? "active" : ""}`}>
            {step > 3 ? "✓" : "3"}
          </div>
          <div className={`step-line ${step > 3 ? "done" : ""}`} />
          <div className={`step-dot ${step === 4 ? "done" : ""}`}>
            {step === 4 ? "✓" : "4"}
          </div>
        </div>

        {/* STEP 1: Category */}
        {step <= 3 && (
          <div className="section">
            <div className="section-title"><span className="num">1</span> Выбери раздел</div>
            <div className="cat-grid">
              {categories.map((c) => (
                <div
                  key={c.id}
                  className={`cat-card ${selectedCat === c.id ? "selected" : ""}`}
                  style={{ "--cat-color": c.accent }}
                  onClick={() => {
                    setSelectedCat(c.id);
                    setSelectedMethods([]);
                    setSelectedSubtypes([]);
                    setPreviousDishes([]);
                    if (step === 1) setStep(2);
                  }}
                >
                  {selectedCat === c.id && (
                    <div className="check-badge" style={{ background: c.accent }}>✓</div>
                  )}
                  <span className="cat-emoji">{c.emoji}</span>
                  <div className="cat-name">{c.title}</div>
                  <div className="cat-sub">{c.subtitle}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* STEP 2: Subtypes (if category has them) + Ingredients */}
        {step >= 2 && step <= 3 && cat && (
          <div className="section">
            {cat.subtypes && cat.subtypes.length > 0 && (
              <>
                <div className="section-title"><span className="num">2</span> Что конкретно?</div>
                <div className="card" style={{ marginBottom: 16 }}>
                  <div className="method-hint">Можно выбрать один вариант или оба сразу</div>
                  <div className="methods-grid">
                    {cat.subtypes.map((s) => (
                      <button
                        key={s.id}
                        className={`method-btn ${selectedSubtypes.includes(s.id) ? "selected" : ""}`}
                        onClick={() => toggleSubtype(s.id)}
                      >
                        {s.emoji} {s.label}
                      </button>
                    ))}
                  </div>
                  {selectedSubtypes.length > 1 && (
                    <div className="compare-note">
                      <span className="ico">💡</span>
                      <span>Покажу отдельный вариант и для печенья, и для пирожного.</span>
                    </div>
                  )}
                </div>
              </>
            )}

            <div className="section-title">
              <span className="num">{cat.subtypes ? 3 : 2}</span> Что есть дома?
            </div>
            <div className="card">
              <textarea
                value={ingredients}
                onChange={(e) => {
                  setIngredients(e.target.value);
                  if (step === 2 && e.target.value.trim().length > 2) setStep(3);
                }}
                placeholder={`Например: ${cat.examples}`}
                rows={4}
              />
              <div className="hint-text">Пиши через запятую всё, что нашлось на кухне</div>
            </div>
          </div>
        )}

        {/* STEP 3: Cooking method */}
        {step >= 3 && step <= 3 && cat && (
          <div className="section">
            <div className="section-title"><span className="num">{cat.subtypes ? 4 : 3}</span> Как будешь готовить?</div>
            <div className="card">
              <div className="method-hint">Можно выбрать сразу несколько способов — покажу варианты под каждый</div>
              <div className="methods-grid">
                {cat.cookingMethods.map((m) => {
                  const idx = selectedMethods.indexOf(m);
                  return (
                    <button
                      key={m}
                      className={`method-btn ${idx !== -1 ? "selected" : ""}`}
                      onClick={() => toggleMethod(m)}
                    >
                      {idx !== -1 && selectedMethods.length > 1 && (
                        <span className="order-pill">{idx + 1}</span>
                      )}
                      {m}
                    </button>
                  );
                })}
                <button
                  className={`method-btn any ${selectedMethods.length === 0 ? "selected" : ""}`}
                  onClick={() => setSelectedMethods([])}
                >
                  Неважно
                </button>
              </div>

              {selectedMethods.length > 1 && (
                <div className="compare-note">
                  <span className="ico">💡</span>
                  <span>
                    Выбрано {selectedMethods.length} способа — покажу отдельный вариант под{" "}
                    {selectedMethods.join(" и ")}, чтобы было ясно, что готовить чем.
                  </span>
                </div>
              )}
            </div>

            {error && <div className="error-box">⚠️ {error}</div>}

            <button
              className="btn-main"
              disabled={!canGenerate || loading}
              onClick={generateIdea}
            >
              {loading ? (
                <>
                  <div className="spinner" />
                  Думаю...
                </>
              ) : (
                <>🔥 Найти рецепт</>
              )}
            </button>
            {loading && <div className="loading-line">{loadingPhrase}</div>}
          </div>
        )}

        {/* STEP 4: Result */}
        {step === 4 && result && cat && (
          <div className="section">
            <div className="section-title">Вот идея для тебя!</div>
            <div className="result-card">
              <div className="result-header" style={{ background: `linear-gradient(135deg, ${cat.accent}, #2A1B12)` }}>
                <h2>{cat.emoji} {cat.title}</h2>
                <p>
                  {cat.subtypes && selectedSubtypes.length > 0 && (
                    <>
                      {cat.subtypes
                        .filter((s) => selectedSubtypes.includes(s.id))
                        .map((s) => s.label)
                        .join(" и ")}
                      {" · "}
                    </>
                  )}
                  {selectedMethods.length === 0
                    ? "Любой способ"
                    : selectedMethods.length === 1
                    ? `Способ: ${selectedMethods[0]}`
                    : `Способы: ${selectedMethods.join(" и ")}`}
                  {" "}· {ingredients.split(",").filter(Boolean).length} ингр.
                </p>
              </div>
              <div className="result-body">
                <div className="result-text">{result}</div>
                <div className="tag-row">
                  {ingredients.split(",").slice(0, 5).map((i, idx) => (
                    <span key={idx} className="tag">{i.trim()}</span>
                  ))}
                  {ingredients.split(",").length > 5 && (
                    <span className="tag">+{ingredients.split(",").length - 5}</span>
                  )}
                </div>
              </div>
            </div>

            {error && <div className="error-box">⚠️ {error}</div>}

            <button className="btn-main" onClick={generateIdea} disabled={loading}>
              {loading ? <><div className="spinner" /> Думаю...</> : "🔄 Другой вариант"}
            </button>
            {loading && <div className="loading-line">{loadingPhrase}</div>}
            <button className="btn-reset" onClick={reset}>
              ← Начать заново
            </button>
          </div>
        )}
      </div>
    </>
  );
}
