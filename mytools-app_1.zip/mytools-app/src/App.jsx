import { useState } from "react";
import SmartTools from "./tools/SmartTools";
import ContentMaker from "./tools/ContentMaker";
import ReelMaker from "./tools/ReelMaker";
import TrendReelMaker from "./tools/TrendReelMaker";
import Oshxona from "./tools/Oshxona";

const TOOLS = [
  {
    id: "smart",
    icon: "✦",
    emoji: "🧠",
    label: "Smart Tools",
    desc: "Резюме, перевод, стихи, имена",
    color: "#7C3AED",
    bg: "linear-gradient(135deg, #7C3AED22, #9333EA11)",
    border: "#7C3AED44",
  },
  {
    id: "content",
    icon: "✍",
    emoji: "✍️",
    label: "Content Maker",
    desc: "Сценарии для Instagram и YouTube",
    color: "#C8F135",
    bg: "linear-gradient(135deg, #C8F13522, #a8d12011)",
    border: "#C8F13544",
  },
  {
    id: "reel",
    icon: "⚡",
    emoji: "🎬",
    label: "Viral Maker",
    desc: "Быстрые сценарии для Reels",
    color: "#E1306C",
    bg: "linear-gradient(135deg, #E1306C22, #c02a5c11)",
    border: "#E1306C44",
  },
  {
    id: "trend",
    icon: "◈",
    emoji: "🔥",
    label: "Trend Reels",
    desc: "Вирусный контент с анализом трендов",
    color: "#69C9D0",
    bg: "linear-gradient(135deg, #69C9D022, #4ab0b811)",
    border: "#69C9D044",
  },
  {
    id: "oshxona",
    icon: "🍽",
    emoji: "👨‍🍳",
    label: "Oshxona AI",
    desc: "AI рецепты узбекской кухни",
    color: "#C0392B",
    bg: "linear-gradient(135deg, #C0392B22, #a02d2211)",
    border: "#C0392B44",
  },
];

export default function App() {
  const [active, setActive] = useState(null);

  const activeTool = TOOLS.find((t) => t.id === active);

  if (active === "smart") return <SmartTools onBack={() => setActive(null)} />;
  if (active === "content")
    return <ContentMaker onBack={() => setActive(null)} />;
  if (active === "reel") return <ReelMaker onBack={() => setActive(null)} />;
  if (active === "trend")
    return <TrendReelMaker onBack={() => setActive(null)} />;
  if (active === "oshxona")
    return <Oshxona onBack={() => setActive(null)} />;

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "linear-gradient(160deg, #0f0c29 0%, #1a1535 50%, #0d1117 100%)",
        fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
        color: "#fff",
        padding: "0 0 40px",
      }}
    >
      {/* Header */}
      <div
        style={{
          padding: "48px 24px 32px",
          background:
            "linear-gradient(180deg, rgba(124,58,237,0.15) 0%, transparent 100%)",
          borderBottom: "1px solid rgba(255,255,255,0.06)",
          textAlign: "center",
        }}
      >
        <div
          style={{
            fontSize: 11,
            fontWeight: 800,
            letterSpacing: 4,
            color: "#7C3AED",
            marginBottom: 12,
            textTransform: "uppercase",
          }}
        >
          AI Toolbox
        </div>
        <h1
          style={{
            margin: 0,
            fontSize: 32,
            fontWeight: 900,
            letterSpacing: -1,
            background: "linear-gradient(135deg, #fff 0%, #a78bfa 100%)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
          }}
        >
          My AI Apps
        </h1>
        <p
          style={{
            color: "rgba(255,255,255,0.4)",
            fontSize: 14,
            marginTop: 8,
            fontWeight: 400,
          }}
        >
          5 ta AI qurol bir joyda
        </p>
      </div>

      {/* Tools Grid */}
      <div style={{ padding: "24px 16px", maxWidth: 480, margin: "0 auto" }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {TOOLS.map((tool) => (
            <button
              key={tool.id}
              onClick={() => setActive(tool.id)}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 16,
                padding: "20px",
                borderRadius: 20,
                background: tool.bg,
                border: `1.5px solid ${tool.border}`,
                cursor: "pointer",
                textAlign: "left",
                transition: "transform 0.15s, box-shadow 0.15s",
                boxShadow: `0 4px 24px ${tool.color}15`,
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = "translateY(-2px)";
                e.currentTarget.style.boxShadow = `0 8px 32px ${tool.color}30`;
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = "translateY(0)";
                e.currentTarget.style.boxShadow = `0 4px 24px ${tool.color}15`;
              }}
            >
              {/* Icon */}
              <div
                style={{
                  width: 56,
                  height: 56,
                  borderRadius: 16,
                  background: `${tool.color}22`,
                  border: `1px solid ${tool.color}44`,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: 26,
                  flexShrink: 0,
                }}
              >
                {tool.emoji}
              </div>

              {/* Text */}
              <div style={{ flex: 1, minWidth: 0 }}>
                <p
                  style={{
                    margin: 0,
                    fontSize: 16,
                    fontWeight: 700,
                    color: "#fff",
                    letterSpacing: -0.3,
                  }}
                >
                  {tool.label}
                </p>
                <p
                  style={{
                    margin: "4px 0 0",
                    fontSize: 13,
                    color: "rgba(255,255,255,0.5)",
                    lineHeight: 1.4,
                  }}
                >
                  {tool.desc}
                </p>
              </div>

              {/* Arrow */}
              <div
                style={{
                  color: tool.color,
                  fontSize: 20,
                  opacity: 0.7,
                  flexShrink: 0,
                }}
              >
                →
              </div>
            </button>
          ))}
        </div>

        {/* Footer */}
        <p
          style={{
            textAlign: "center",
            fontSize: 11,
            color: "rgba(255,255,255,0.15)",
            marginTop: 32,
            letterSpacing: 2,
            textTransform: "uppercase",
          }}
        >
          Powered by Gemini AI
        </p>
      </div>
    </div>
  );
}
