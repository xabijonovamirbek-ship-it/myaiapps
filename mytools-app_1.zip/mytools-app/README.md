# My AI Apps — PWA

5 ta AI qurol bir joyda. Telefoningizga **ilovalar kabi o'rnatish** mumkin (PWA).

---

## 📱 Ilovalar

| # | Nomi | Tavsif |
|---|------|--------|
| 1 | **Smart Tools** | Rezyume, tarjima, she'r, ismlar |
| 2 | **Content Maker** | Instagram/YouTube skript generatori |
| 3 | **Viral Maker** | Tez Reels ssenariylar |
| 4 | **Trend Reels** | Trendli viral kontent |
| 5 | **Oshxona AI** | O'zbek taomlari retseptlari |

---

## 🚀 Vercelga deploy qilish

### 1-qadam: GitHub repozitoriyasi yaratish

1. GitHub.com ga kiring
2. **New repository** → nom bering (masalan: `myaiapps`)
3. **Public** → **Create repository**

### 2-qadam: Fayllarni yuklash

Kompyuteringizda terminal oching va:

```bash
cd mytools-app
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/SIZNING_USERNAME/myaiapps.git
git push -u origin main
```

### 3-qadam: Vercelga ulash

1. [vercel.com](https://vercel.com) ga kiring
2. **Add New Project** → GitHub repositoriyangizni tanlang
3. Framework: **Vite** (avtomatik aniqlanadi)
4. **Deploy** bosing — kutib turing

### 4-qadam: Gemini API kalitini qo'shish ⚠️ MUHIM

Deploy bo'lgandan keyin:

1. Vercel dashboard → Loyihangizni oching
2. **Settings** → **Environment Variables**
3. Qo'shing:
   - **Name:** `GEMINI_API_KEY`
   - **Value:** Sizning Google AI Studio kalitingiz
   - **Environment:** Production, Preview, Development (barchasini belgilang)
4. **Save** bosing
5. **Deployments** → **Redeploy** (qayta deploy qilish kerak!)

### 5-qadam: Telefoningizga o'rnatish

**Android (Chrome):**
1. Saytingizni Chromeda oching
2. Yuqorida uchta nuqta (⋮) → **"Qurilmaga qo'shish"**
3. **O'rnatish** — tayyor!

**iPhone (Safari):**
1. Saytingizni Safarida oching
2. Pastdagi ulashish tugmasi (⬆️)
3. **"Bosh ekranga qo'shish"**
4. **Qo'shish** — tayyor!

---

## 🔧 Muammolar

**API ishlamayapti?**
- Vercel → Settings → Environment Variables ni tekshiring
- `GEMINI_API_KEY` qo'shilganmi?
- Redeploy qildingizmi?

**Google AI Studio kaliti qayerdan?**
1. [aistudio.google.com](https://aistudio.google.com) ga kiring
2. **Get API key** → **Create API key**
3. Nusxa oling va Vercelga qo'shing

---

## 📁 Loyiha tuzilishi

```
mytools-app/
├── api/
│   └── ai.js          ← Gemini API proxisi (server tomonida)
├── public/
│   ├── manifest.json  ← PWA manifest
│   ├── sw.js          ← Service Worker
│   └── icons/         ← Ilova ikonkalari
├── src/
│   ├── App.jsx        ← Asosiy hub (5 kategoriya)
│   ├── main.jsx       ← Kirish nuqtasi
│   └── tools/
│       ├── SmartTools.jsx
│       ├── ContentMaker.jsx
│       ├── ReelMaker.jsx
│       ├── TrendReelMaker.jsx
│       └── Oshxona.jsx
├── index.html
├── package.json
├── vite.config.js
└── vercel.json
```

---

## ℹ️ Qanday ishlaydi

- **Frontend** → Vercelda statik fayl sifatida joylashadi
- **API chaqiruvlar** → `/api/ai` endpointiga boradi (eski `api.anthropic.com` emas)
- **Backend** → `api/ai.js` Gemini APIni chaqiradi, API kalitingiz faqat serverda
- **PWA** → `manifest.json` + `sw.js` orqali telefonga o'rnatish imkoni beradi
