// api/ai.js — Vercel Serverless Function
// Accepts requests in Anthropic Messages API format,
// translates them to Gemini API, returns same format back.

export const config = { runtime: "edge" };

const GEMINI_URL =
  "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent";

export default async function handler(req) {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type",
      },
    });
  }

  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: { "Content-Type": "application/json" },
    });
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return new Response(
      JSON.stringify({ error: "GEMINI_API_KEY not configured on server" }),
      { status: 500, headers: { "Content-Type": "application/json" } }
    );
  }

  try {
    const body = await req.json();
    const { system, messages = [], tools = [] } = body;

    // Build Gemini contents from Anthropic messages
    const contents = messages.map((m) => ({
      role: m.role === "assistant" ? "model" : "user",
      parts: [
        {
          text:
            typeof m.content === "string"
              ? m.content
              : m.content.map((c) => c.text || "").join(""),
        },
      ],
    }));

    // Build system instruction
    const systemInstruction = system
      ? { parts: [{ text: system }] }
      : undefined;

    // Check if web search tool is requested
    const hasWebSearch = tools.some(
      (t) => t.type === "web_search_20250305" || t.name === "web_search"
    );

    const geminiBody = {
      contents,
      ...(systemInstruction && { systemInstruction }),
      generationConfig: {
        maxOutputTokens: body.max_tokens || 1000,
        temperature: 0.7,
      },
      ...(hasWebSearch && {
        tools: [{ googleSearch: {} }],
      }),
    };

    const geminiResp = await fetch(`${GEMINI_URL}?key=${apiKey}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(geminiBody),
    });

    if (!geminiResp.ok) {
      const errText = await geminiResp.text();
      return new Response(
        JSON.stringify({ error: `Gemini error: ${errText}` }),
        {
          status: 502,
          headers: { "Content-Type": "application/json" },
        }
      );
    }

    const geminiData = await geminiResp.json();

    // Extract text from Gemini response
    const text =
      geminiData.candidates?.[0]?.content?.parts
        ?.map((p) => p.text || "")
        .join("") || "";

    // Return in Anthropic format so frontend code stays unchanged
    const anthropicFormat = {
      id: "gemini-proxy",
      type: "message",
      role: "assistant",
      content: [{ type: "text", text }],
      model: "gemini-2.0-flash",
      stop_reason: "end_turn",
      usage: { input_tokens: 0, output_tokens: 0 },
    };

    return new Response(JSON.stringify(anthropicFormat), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
}
